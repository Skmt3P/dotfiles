<?php

use Twig\NodeVisitor\OptimizerNodeVisitor;

class_exists('Twig\NodeVisitor\OptimizerNodeVisitor');

if (\false) {
    class Twig_NodeVisitor_Optimizer extends OptimizerNodeVisitor
    {
    }
}
