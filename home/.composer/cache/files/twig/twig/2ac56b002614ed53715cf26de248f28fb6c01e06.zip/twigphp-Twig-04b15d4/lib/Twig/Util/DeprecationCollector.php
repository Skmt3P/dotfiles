<?php

use Twig\Util\DeprecationCollector;

class_exists('Twig\Util\DeprecationCollector');

if (\false) {
    class Twig_Util_DeprecationCollector extends DeprecationCollector
    {
    }
}
