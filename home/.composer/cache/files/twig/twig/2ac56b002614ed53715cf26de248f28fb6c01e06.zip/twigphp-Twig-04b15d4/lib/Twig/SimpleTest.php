<?php

use Twig\TwigTest;

class_exists('Twig\TwigTest');

if (\false) {
    class Twig_SimpleTest extends TwigTest
    {
    }
}
