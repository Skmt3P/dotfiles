<?php

use Twig\Compiler;

class_exists('Twig\Compiler');

if (\false) {
    class Twig_Compiler extends Compiler
    {
    }
}
