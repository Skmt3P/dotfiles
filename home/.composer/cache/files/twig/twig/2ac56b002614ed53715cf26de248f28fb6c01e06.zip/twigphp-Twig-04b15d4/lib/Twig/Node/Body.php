<?php

use Twig\Node\BodyNode;

class_exists('Twig\Node\BodyNode');

if (\false) {
    class Twig_Node_Body extends BodyNode
    {
    }
}
