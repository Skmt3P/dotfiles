<?php

use Twig\Test\NodeTestCase;

class_exists('Twig\Test\NodeTestCase');

if (\false) {
    class Twig_Test_NodeTestCase extends NodeTestCase
    {
    }
}
