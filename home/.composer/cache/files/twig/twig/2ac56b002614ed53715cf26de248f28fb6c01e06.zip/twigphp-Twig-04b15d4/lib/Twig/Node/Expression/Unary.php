<?php

use Twig\Node\Expression\Unary\AbstractUnary;

class_exists('Twig\Node\Expression\Unary\AbstractUnary');

if (\false) {
    class Twig_Node_Expression_Unary extends AbstractUnary
    {
    }
}
