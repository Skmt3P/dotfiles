<?php

use Twig\Node\AutoEscapeNode;

class_exists('Twig\Node\AutoEscapeNode');

if (\false) {
    class Twig_Node_AutoEscape extends AutoEscapeNode
    {
    }
}
