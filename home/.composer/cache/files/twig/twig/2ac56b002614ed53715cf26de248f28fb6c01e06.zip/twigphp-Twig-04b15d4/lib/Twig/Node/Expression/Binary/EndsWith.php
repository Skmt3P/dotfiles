<?php

use Twig\Node\Expression\Binary\EndsWithBinary;

class_exists('Twig\Node\Expression\Binary\EndsWithBinary');

if (\false) {
    class Twig_Node_Expression_Binary_EndsWith extends EndsWithBinary
    {
    }
}
