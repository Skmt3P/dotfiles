<?php

use Twig\Node\Expression\GetAttrExpression;

class_exists('Twig\Node\Expression\GetAttrExpression');

if (\false) {
    class Twig_Node_Expression_GetAttr extends GetAttrExpression
    {
    }
}
