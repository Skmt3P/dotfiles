<?php

use Twig\Node\Expression\Binary\LessEqualBinary;

class_exists('Twig\Node\Expression\Binary\LessEqualBinary');

if (\false) {
    class Twig_Node_Expression_Binary_LessEqual extends LessEqualBinary
    {
    }
}
