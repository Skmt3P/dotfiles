<?php

use Twig\TokenParser\SpacelessTokenParser;

class_exists('Twig\TokenParser\SpacelessTokenParser');

if (\false) {
    class Twig_TokenParser_Spaceless extends SpacelessTokenParser
    {
    }
}
