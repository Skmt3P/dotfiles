<?php

use Twig\NodeTraverser;

class_exists('Twig\NodeTraverser');

if (\false) {
    class Twig_NodeTraverser extends NodeTraverser
    {
    }
}
